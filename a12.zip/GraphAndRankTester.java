import java.util.ArrayList;


/*  Student information for assignment:
 *
  *  On my honor, <Christopher Philip>, this programming assignment is my own work
 *  and I have not provided this code to any other student.
 *
 *  Name: Christopher Philip
 *  email address: christopher.philip117@gmail.com
 *  UTEID: cp26645
 *  Section 5 digit ID: 88620
 *  Grader name: Kris Vandercook
 *  Number of slip days used on this assignment: 0
 */

/*
 * Question. The assignment presents three ways to rank teams using graphs.
 * The results, especially for the last two methods are reasonable.
 * However if all results from all college football teams are included
 * some unexpected results occur.
 *
 * Suggest another way of method of ranking teams using the results
 * from the graph. Thoroughly explain your method. The method can build
 * on one of the three existing algorithms.
 * 
 * One possible way to improve the ranking is to take into consideration the player's
 * skill when determining rank. This way, if one team of lower skill beats a team of higher skill, 
 * they can ascend the ranks quicker due to their achievement. Likewise if a team of 
 * higher skill beats a team of lower skill, they will not ascend as fast because they
 * have not shown anything truly impressive, as it would be easily predicted. 
 *
 */



//Tests provided by Spring 2015 CS314 friends :D
public class GraphAndRankTester {

   public static void main(String[] args)  
   {
       studentTests();
   }
   public static void studentTests()
   {
	   String [][] edges = 
		   	  {{"A", "B", "10"},
			   {"B", "C", "30"},
			   {"B", "D", "132"},
			   {"C", "F", "34"},
			   {"A", "G", "75"},
			   {"D", "F", "4"},
			   {"D", "G", "5"},
			   {"D", "E", "102"}};
	   
	   Graph g = new Graph();
	   
	   for(String[] edge : edges) 
	   {
		   g.addEdge(edge[0], edge[1], Integer.parseInt(edge[2]));
		   g.addEdge(edge[1], edge[0], Integer.parseInt(edge[2]));
	   }
	   
	   System.out.println("** STUDENT WRITTEN TESTS **");
	   String actualPath = "";
	   ArrayList<String> expectedPath = new ArrayList<String>();
	   ArrayList<String> vertex = new ArrayList<String>();
	   String vertices = "ABCDEFG";

	   for(int i = 0; i < 7; i++)
	   {
		   vertex.add("" + vertices.charAt(i));
	   }

	   expectedPath.add("[A]");
	   expectedPath.add("[A, B]");
	   expectedPath.add("[A, B, C]");
	   expectedPath.add("[A, B, C, F, D]");
	   expectedPath.add("[A, B, C, F, D, E]");
	   expectedPath.add("[A, B, C, F]");
	   expectedPath.add("[A, G]");

	   g.dijkstra("A");

	   //Dijkstra Print Tests 1- 10
	   for(int i = 0; i < 7; i++)
	   {
		   actualPath = g.findPath(vertex.get(i)).toString();
		   if(actualPath.equals(expectedPath.get(i)))
		   {
			   System.out.printf("Dijstra Test: %-40d	| PASSED\n", i +1);
		   }else
		   {
			   System.out.printf("Dijstra Test %d:	Expected: %-20s Actual: %-20s | FAILED\n", i+1, expectedPath.get(i), actualPath);
		   }
	   }

	   System.out.println();
	   //findAllPaths Print Tests 1-10

	   g.findAllPaths(true);
	   int actualDiameter = g.getDiameter();
	   int expectedDiameter = 5;
	   double actualCostOfLongestPath = g.costOfLongestShortestPath();
	   double expectedCostOfLongestPath = 180.0;

	   if(actualDiameter == expectedDiameter && expectedCostOfLongestPath == actualCostOfLongestPath)
	   {
		   System.out.printf("FindAllPaths Test Weighted: %-28d| PASSED\n", 1);
	   }
	   else
	   {
		   System.out.printf("FindAllPaths Test Weighted: %-28d| FAILED\n", 1);
		   System.out.printf("	Expected Diameter: %d	Actual Diameter: %d\n", expectedDiameter, actualDiameter);
		   System.out.printf("	Expected costOfLongestPath: %f Actual costOfLongestPath: %f\n", expectedCostOfLongestPath, actualCostOfLongestPath);
	   }
	   
	   String[] expectedPaths = 
		   {   "Name: F                    cost per path: 48.5000, num paths: 6",
               "Name: D                    cost per path: 49.1667, num paths: 6",
               "Name: G                    cost per path: 52.0000, num paths: 6",
               "Name: C                    cost per path: 54.1667, num paths: 6",
               "Name: B                    cost per path: 69.1667, num paths: 6",
               "Name: A                    cost per path: 76.1667, num paths: 6",
               "Name: E                    cost per path: 134.1667, num paths: 6"};
	   
	   testAllPathsInfo(g, expectedPaths);
	   
	   g.findAllPaths(false);
	   actualDiameter = g.getDiameter();
	   expectedDiameter = 3;
	   actualCostOfLongestPath = g.costOfLongestShortestPath();
	   expectedCostOfLongestPath = 3;

	   if(actualDiameter == expectedDiameter && expectedCostOfLongestPath == actualCostOfLongestPath)
	   {
		   System.out.printf("FindAllPaths Test un-weighted on connected graph: %-6d| PASSED\n", 2);
	   }
	   else
	   {
		   System.out.printf("FindAllPaths Test un-weighted on connected graph: %-6d| FAILED\n", 2);
		   System.out.printf("	Expected Diameter: %d	Actual Diameter: %d\n", expectedDiameter, actualDiameter);
		   System.out.printf("	Expected costOfLongestPath: %f Actual costOfLongestPath: %f\n", expectedCostOfLongestPath, actualCostOfLongestPath);
	   }
	   
	   expectedPaths = new String []{
			   "Name: D                    cost per path: 1.3333, num paths: 6",
               "Name: B                    cost per path: 1.5000, num paths: 6",
               "Name: F                    cost per path: 1.8333, num paths: 6",
               "Name: G                    cost per path: 1.8333, num paths: 6",
               "Name: A                    cost per path: 2.0000, num paths: 6",
               "Name: C                    cost per path: 2.0000, num paths: 6",
               "Name: E                    cost per path: 2.1667, num paths: 6"};
	   
	   testAllPathsInfo(g, expectedPaths);
	   
	   String [][] unconnectedGraph =
	       {{"A", "B", "130"},
	        {"A", "C", "340"},
	        {"A", "D", "35"},
	        {"B", "E", "566"},
	        {"C", "B", "11"},
	        {"D", "C", "5"},
	        {"E", "G", "45"},
	        {"E", "F", "89"},
	        {"F", "C", "12"},
	        {"F", "E", "34"},
	        {"G", "F", "90"},
	        {"H", "I", "12"},
	        {"H", "J", "53"},
	        {"H", "K", "12"},
	        {"I", "K", "356"},
	        {"I", "J", "109"},
	        {"J", "L", "812"}};


	       g = new Graph();
	       for(String[] edge : unconnectedGraph) {
	           g.addEdge(edge[0], edge[1], Integer.parseInt(edge[2]));
	       }
	       
	       g.findAllPaths(true);
		   actualDiameter = g.getDiameter();
		   expectedDiameter = 2;
		   actualCostOfLongestPath = g.costOfLongestShortestPath();
		   expectedCostOfLongestPath = 921.0;

		   if(actualDiameter == expectedDiameter && expectedCostOfLongestPath == actualCostOfLongestPath){
			   System.out.printf("FindAllPaths Test un-weighted on un-connected graph: %-3d| PASSED\n", 3);
		   }else{
			   System.out.printf("FindAllPaths Test un-weighted on un-connected graph: %-3d| FAILED\n", 3);
			   System.out.printf("	Expected Diameter: %d	Actual Diameter: %d\n", expectedDiameter, actualDiameter);
			   System.out.printf("	Expected costOfLongestPath: %f Actual costOfLongestPath: %f\n", expectedCostOfLongestPath, actualCostOfLongestPath);
		   }
		   
		   expectedPaths = new String [] {
			  "Name: A                    cost per path: 351.8333, num paths: 6",
              "Name: D                    cost per path: 380.2000, num paths: 5",
              "Name: F                    cost per path: 37.0000, num paths: 4",
              "Name: E                    cost per path: 86.7500, num paths: 4",
              "Name: G                    cost per path: 107.2500, num paths: 4",
              "Name: H                    cost per path: 235.5000, num paths: 4",
              "Name: C                    cost per path: 469.0000, num paths: 4",
              "Name: B                    cost per path: 624.7500, num paths: 4",
              "Name: I                    cost per path: 462.0000, num paths: 3",
              "Name: J                    cost per path: 812.0000, num paths: 1"};

		   testAllPathsInfo(g, expectedPaths);
		  
   }
  
   private static void testAllPathsInfo(Graph g, String[] expectedPaths)
   {
       int index = 0;

       for(AllPathsInfo api : g.getAllPaths()) {
           if(expectedPaths[index].equals(api.toString())) {
               System.out.println(expectedPaths[index] + " is correct!!");
           }
           else {
               System.out.println("ERROR IN ALL PATHS INFO: ");
               System.out.println("index: " + index);
               System.out.println("EXPECTED: " + expectedPaths[index]);
               System.out.println("ACTUAL: " + api.toString());
               System.out.println();
           }
           index++;
       }
       System.out.println();
   }
}