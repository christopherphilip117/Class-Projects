import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Map;

//*  On <OUR> honor, <Christopher Philip> and <Jorge Zapien), this programming assignment is <OUR> own work
//*  and <WE> have not provided this code to any other student.
//*  
//*  
//**  Number of slip days used: 0 
//*
//*
//*  Student 1 (Student whose turnin account is being used)
//*  UTEID: cp26645
//*  email address: christopher.philip117@gmail.com
//*  Grader name: Kris
//*  Section number: 88620
//*
//*  Student 2
//*  UTEID: jaz747
//*  email address: zapien256@gmail.com
//*  Grader name: Kris
//*  Section number: 88620

public class Compressor implements IHuffConstants{
	//Instance Vairables
	private IHuffViewer GUI;
	private HuffmanTree tree;
	private int[] freqs;
	private BitInputStream bInput;
	private BitOutputStream bOutput;
	private int header;
	private Map<Integer, String> codes;
	
	//Constructor
	public Compressor(IHuffViewer GUI, HuffmanTree tree, int[] freqs, int header,  
			InputStream input, OutputStream output, Map<Integer, String> codes){
		this.GUI = GUI;
		this.tree = tree;
		this.freqs = freqs;
		this.header = header;
		this.bInput = new BitInputStream(input);
		this.bOutput = new BitOutputStream(output);
		this.codes = codes;
	}
	
	public void Compress() throws IOException{
		showMessage("COMPRESSING...");
		writeHeader();
		readData();
		showMessage("COMPRESSION COMPLETE.");
	}

	//Method that writes header to encode
	private void writeHeader(){
		bOutput.writeBits(BITS_PER_INT, MAGIC_NUMBER);
		if(header == STORE_COUNTS){
			showMessage("WRITING HEADER IN STANDARD COUNT FORMAT...");
			bOutput.writeBits(BITS_PER_INT, STORE_COUNTS);
			for(int i: freqs){
				bOutput.writeBits(BITS_PER_INT, i);
			}
		}
		
		else if(header == STORE_TREE){
			showMessage("WRITING HEADER IN STANDARD TREE FORMAT...");
			bOutput.writeBits(BITS_PER_INT, STORE_TREE);
			String treeToBits = tree.getTreeCode();
			String treeBinary = Integer.toBinaryString(treeToBits.length());
			int treeBitsLength = treeBinary.length();
			for(int i = 0; i < BITS_PER_INT - treeBitsLength; i++)
				bOutput.writeBits(1, '0');
			String completeBitsString = treeBinary + treeToBits;
			for(char c:completeBitsString.toCharArray())
				bOutput.writeBits(1, c);
		}
		
		//Invalid Header
		else
			GUI.showError("INVALID HEADER FORMAT");
		
	}
	
	//Read in data
	private void readData() throws IOException{
		showMessage("READING AND WRITING DATA...");
		int inbits;
		while ((inbits = bInput.readBits(BITS_PER_WORD)) != -1) {
		    writeData(codes.get(inbits));
		} 
		writeData(codes.get(PSEUDO_EOF));
		bInput.close();
		bOutput.close();
	}
	
	//Write data to output file
	private void writeData(String input) throws IOException{
		for(char ch: input.toCharArray()){
			bOutput.writeBits(1, ch);
		}
	}
	
	private void showMessage(String message){
		if(GUI != null)
			GUI.update(message);
	}
}
