import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

//*  On <OUR> honor, <Christopher Philip> and <Jorge Zapien), this programming assignment is <OUR> own work
//*  and <WE> have not provided this code to any other student.
//*  
//*  
//**  Number of slip days used: 0 
//*
//*
//*  Student 1 (Student whose turnin account is being used)
//*  UTEID: cp26645
//*  email address: christopher.philip117@gmail.com
//*  Grader name: Kris
//*  Section number: 88620
//*
//*  Student 2
//*  UTEID: jaz747
//*  email address: zapien256@gmail.com
//*  Grader name: Kris
//*  Section number: 88620


public class HuffmanTree implements IHuffConstants {
	//instance variables
	private TreeNode root;
	private int size;
	private static final int LEAF_BITS = 9;
	
	//Constructor
	public HuffmanTree(PriorityQueue<TreeNode> pq){
		size = 0;
		root = null;
		buildTree(pq);
	}
	
	//Zero argument constructor
	public HuffmanTree() {
		size = 0;
		root = null;
	}


	public void buildTree(PriorityQueue<TreeNode> pq){
		while(pq.size() >= 2){
			TreeNode leftChild = pq.front();
			pq.dequeue();
			TreeNode rightChild = pq.front();
			pq.dequeue();
			
			//Creates new node with children nodes
			int leftWeight = leftChild.getFrequency();
			int rightWeight = rightChild.getFrequency();
			TreeNode node = new TreeNode((leftWeight + rightWeight), leftChild, rightChild);
			pq.enqueue(node);
			this.size += 3;
		}
		root = pq.front();
		pq.dequeue();
		
	}
	
	public TreeNode getTree(){
		return root;
	}
	
	public int size(){
		return size;
	}
	
	//Gets Huff codes for each character
	public Map<Integer, String> getCodes(){
		if(root == null)
			throw new IllegalStateException("HuffMan Tree is empty");
		
		TreeMap<Integer, String> codes = new TreeMap<Integer, String>();
		getCodesHelper(root, "", codes);
		return codes;
	}
	
	//Helper method for getCodes
	private void getCodesHelper(TreeNode node, String code, TreeMap<Integer, String> codes){
		if(node != null){
			//Add code to map if leaf
			if(isLeaf(node)) {
				codes.put(node.getValue(), code);
			}
			//Go left 
			if(node.getLeft() != null)
				getCodesHelper(node.getLeft(), code + "0", codes);
			//Go right
			if(node.getRight() != null)
				getCodesHelper(node.getRight(), code + "1", codes);	
		}
	}
	
	//Method that generates a code to navigate the tree
	public String getTreeCode(){
		StringBuilder sb = new StringBuilder();
		getTreeCodeHelper(this.root, sb);
		return sb.toString();
	}
	
	//Helper method for getTreeCode
	private void getTreeCodeHelper(TreeNode node, StringBuilder sb){
		if(node != null){
			if(!isLeaf(node))
				sb.append("0");
			else{
				sb.append("1");
				String binaryString = Integer.toBinaryString(node.getValue());
				int numBits = binaryString.length();
				for(int i = 0; i < LEAF_BITS - numBits; i++){
					sb.append("0");
				}
				sb.append(binaryString);
			}
		
		getTreeCodeHelper(node.getLeft(), sb);
		getTreeCodeHelper(node.getRight(), sb);
		}
	}
	
	public boolean isLeaf(TreeNode node){
		return (node.getLeft() == null && node.getRight() == null);
	}
	
	//Reconstruct a tree from a given list of characters
	public HuffmanTree rebuild(LinkedList<Integer> chars){
		if(!validList(chars))
			throw new IllegalArgumentException("Error: Invalid Character List.");
		HuffmanTree result = new HuffmanTree();
		if(chars.size() == 0)
			return result;
			
		result.root = rebuildHelper(chars, root);
		return result;
	}
	
	//Helper Method for rebuild
	private TreeNode rebuildHelper(LinkedList<Integer> chars, TreeNode node) {
		int nextInt = chars.removeFirst();
		//Create leaf node
		if(nextInt >= 0)
			node = new TreeNode(nextInt, 1);
		
		//Create a parent node
		else {
			node = new TreeNode(0, rebuildHelper(chars, null), new TreeNode(0, 0));
			if(!chars.isEmpty())
				node = new TreeNode(0, node.getLeft(), rebuildHelper(chars, null));
		}
		
		return node;
	}

	//Checks to see if given list is valid
	private boolean validList(List<Integer> chars) {
		for(int i = 0; i < chars.size(); i++)
			if(chars.get(i) == null)
				return false;
		return true;	
	}

}
