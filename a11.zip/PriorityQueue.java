
import java.util.Iterator;
import java.util.LinkedList;

//*  On <OUR> honor, <Christopher Philip> and <Jorge Zapien), this programming assignment is <OUR> own work
//*  and <WE> have not provided this code to any other student.
//*  
//*  
//**  Number of slip days used: 0 
//*
//*
//*  Student 1 (Student whose turnin account is being used)
//*  UTEID: cp26645
//*  email address: christopher.philip117@gmail.com
//*  Grader name: Kris
//*  Section number: 88620
//*
//*  Student 2
//*  UTEID: jaz747
//*  email address: zapien256@gmail.com
//*  Grader name: Kris
//*  Section number: 88620

public class PriorityQueue<E extends Comparable<? super E>> {
	
	//Instance Variables
	private LinkedList<E> queue;
	

	//Constructor
	public PriorityQueue() {
		queue = new LinkedList<E>();
	}
	
	public boolean enqueue(E item) {
		if(item == null)
			throw new IllegalArgumentException("Failed Precondition: item != null");
		
		boolean done = false;
		int index = 0;
		Iterator<E> it = queue.iterator();
		
		//Find the index at which to insert the item
		while(it.hasNext() && done == false) {
			E val = it.next();
			if(item.compareTo(val) < 0)
				done = true;
			else
				index++;
		}
		
		if(index >= queue.size())
			queue.addLast(item);
		else
			queue.add(index, item);
		return true;
	}
	
	public boolean dequeue() {
		if(queue.size() == 0)
			throw new IllegalArgumentException("Failed Precondition: queue.size() != 0");
		queue.removeFirst();
		return true;
	}
	
	public int size() {
		return queue.size();
	}
	
	public E front(){
		return queue.peek();
	}
	
	public void clear(){
		queue.clear();
	}
	
	public Iterator<E> iterator(){
		return queue.iterator();
	}
	
	public String toString(){
		return queue.toString();
	}
	
}
