import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Map;

//*  On <OUR> honor, <Christopher Philip> and <Jorge Zapien), this programming assignment is <OUR> own work
//*  and <WE> have not provided this code to any other student.
//*  
//*  
//**  Number of slip days used: 0 
//*
//*
//*  Student 1 (Student whose turnin account is being used)
//*  UTEID: cp26645
//*  email address: christopher.philip117@gmail.com
//*  Grader name: Kris
//*  Section number: 88620
//*
//*  Student 2
//*  UTEID: jaz747
//*  email address: zapien256@gmail.com
//*  Grader name: Kris
//*  Section number: 88620

public class SimpleHuffProcessor implements IHuffProcessor {
    
	private int input;
	private int output;
	private int header;
	private int[] freqCount;
    private IHuffViewer myViewer;
    private HuffmanTree tree;
    private Map<Integer, String> treeCodes;
    
    public int compress(InputStream in, OutputStream out, boolean force) throws IOException {
        if(input - output < 0 && !force){
        	myViewer.showError("COMPRESSED FILE WILL HAVE " + (input - output) + " MORE BITS THAN ORIGINAL FILE. " 
        + "\n" + "SELECT FORCE COMPRESSION TO COMPRESS FILE.");
        	return -1;
        }
        Compressor comp = new Compressor(myViewer, tree, freqCount, header, in, out, treeCodes);
        comp.Compress();
        showMessage("\n" + "Input Size: " + input + "\n" + "Output Size: " + output + "\n" + "Size Difference: " 
        + (input - output));
        showMessage("\n " + "Percent Compressed: " + (((double) (input - output) / input) * 100) + "%" + "\n");
        in.close();
        out.close();
        return (input - output);
    }

    public int preprocessCompress(InputStream in, int headerFormat) throws IOException {
    	if(headerFormat != STORE_COUNTS && headerFormat != STORE_TREE)
    		myViewer.showError("INVALID HEADER FORMAT");
        BitInputStream bInput = new BitInputStream(in);
        input = 0;
        output = 0;
        header = headerFormat;
        freqCount = new int[ALPH_SIZE];
        readBits(bInput);
        makeTree();
        updateOutput(in);
        if(myViewer != null) {
	        for(int i:treeCodes.keySet()) {
	        	if(i < ALPH_SIZE)
	        		showMessage("CHAR: " + (char) i + "   FREQUENCY: " + freqCount[i] + "   CODE: " + treeCodes.get(i));
	        	else
	        		showMessage("CHAR: " + "PSEUDO_EOF" + "   FREQUENCY: " + 1 + "   CODE: " + treeCodes.get(i));
	        }
        }
        bInput.close();
        in.close();
        return input - output;
    }
    
    //Helper Method for preProcessCompress
    //updates output, makes a priorityQueue, and makes a tree
    private void makeTree(){
    	
    	PriorityQueue<TreeNode> pq = new PriorityQueue<TreeNode>();
    	for(int i = 0; i < ALPH_SIZE; i++){
    		if(header == STORE_COUNTS){
    			output += BITS_PER_INT;
    		}
    		if(freqCount[i] > 0){
    			if(header == STORE_TREE){
    				output += BITS_PER_WORD + 1;
    			}
    			pq.enqueue(new TreeNode(i, freqCount[i]));
    		}
    	}
    	pq.enqueue(new TreeNode(PSEUDO_EOF, 1));
    	int pqSize= pq.size();
    	tree = new HuffmanTree(pq);
    	treeCodes = tree.getCodes();
    	
    	if(header == STORE_TREE){
    		output += tree.size() - pqSize;
    		output += BITS_PER_INT;
    		output += BITS_PER_WORD + 1;
    	}
    }
    
    //Helper Method for preProcessCompress()
    //Reads bits and finds Frequencies
    private void readBits(BitInputStream bInput) throws IOException {
    	int inbits;
        while((inbits = bInput.readBits(BITS_PER_WORD)) != -1) {
        	input += BITS_PER_WORD;
        	freqCount[inbits]++;
        }
    }
    
    //Helper Method
    private void updateOutput(InputStream input) throws IOException{
    	//This accounts for the MAGIC_NUMBER and Header type
    	output += 2 * BITS_PER_INT;
    	
    	//Accounts for the huff codes of each character
    	for(int ch:treeCodes.keySet())
    		if(ch != PSEUDO_EOF)
    			output += treeCodes.get(ch).length() * freqCount[ch];
    	output += treeCodes.get(PSEUDO_EOF).length();
    	
    	input.close();
    }

    public void setViewer(IHuffViewer viewer) {
        myViewer = viewer;
    }

    public int uncompress(InputStream in, OutputStream out) throws IOException {
        Decompressor deComp = new Decompressor(myViewer, in, out);
        return deComp.decompress();
    }
    
    private void showMessage(String s){
        if(myViewer != null)
            myViewer.update(s);
    }
}
