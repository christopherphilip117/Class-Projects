import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.LinkedList;

//*  On <OUR> honor, <Christopher Philip> and <Jorge Zapien), this programming assignment is <OUR> own work
//*  and <WE> have not provided this code to any other student.
//*  
//*  
//**  Number of slip days used: 0 
//*
//*
//*  Student 1 (Student whose turnin account is being used)
//*  UTEID: cp26645
//*  email address: christopher.philip117@gmail.com
//*  Grader name: Kris
//*  Section number: 88620
//*
//*  Student 2
//*  UTEID: jaz747
//*  email address: zapien256@gmail.com
//*  Grader name: Kris
//*  Section number: 88620

public class Decompressor implements IHuffConstants{
	//Instance Vairables
	private IHuffViewer GUI;
	private BitInputStream bInput;
	private BitOutputStream bOutput;
	private int output;
	private HuffmanTree tree;
	private int header;
	
	//Constructor
	public Decompressor(IHuffViewer GUI, InputStream iStream, OutputStream oStream) throws IOException{
		bInput = new BitInputStream(iStream);
		bOutput = new BitOutputStream(oStream);
		output = 0;
		tree = new HuffmanTree();
		this.GUI = GUI;
	}
	
	public int decompress() throws IOException{
		//Check for MAGIC_NUMBER
		showMessage("VERIFYING MAGIC NUMBER...");
		int verify = bInput.readBits(BITS_PER_INT);
		if(verify != MAGIC_NUMBER)
			GUI.showError("MAGIC NUMBER NOT FOUND.");
		//Checking header format
		if(!(checkHeader()))
				return -1;
		showMessage("DECOMPRESSING...");
		readData();
		if(tree.getTree().getValue() != PSEUDO_EOF)
			writeData(tree.getTree());
		showMessage("DECOMPRESSION COMPLETE.");
		bInput.close();
		bOutput.close();
		return (output);
	}

	//Checks to see if the header is valid
	private boolean checkHeader() throws IOException{
		showMessage("CHECKING HEADER...");
		header = bInput.readBits(BITS_PER_INT);
		if(header != STORE_TREE && header != STORE_COUNTS){
			GUI.showError("INVALID HEADER FORMAT.");
			return false;
		}
		return true;
	}

	//Method that reads in data from the stream
	private void readData() throws IOException{
		showMessage("READING DATA...");
		if(header == STORE_COUNTS)
			readSTC();
		else if(header == STORE_TREE)
			readSTF();
		else
			GUI.showError("ERROR: INVALID HEADER FORMAT");
	}
	
	//Method that reads in Standard Count Format
	private void readSTC() throws IOException{
		int[] freqs = new int[ALPH_SIZE];
		for(int i = 0; i < ALPH_SIZE; i++){
			int bit = bInput.readBits(BITS_PER_INT);
			freqs[i] = bit;
		}
		PriorityQueue<TreeNode> pq = new PriorityQueue<TreeNode>();
		for(int i = 0; i < ALPH_SIZE; i++)
			if(freqs[i] > 0)
				pq.enqueue(new TreeNode(i, freqs[i]));
		
		pq.enqueue(new TreeNode(PSEUDO_EOF, 1));
		tree = new HuffmanTree(pq);
	}
	
	//Method that reads in Standard Tree Format
	private void readSTF() throws IOException{
		String size = "";
		for (int i = 0; i < BITS_PER_INT; i++) {
			int bit = bInput.readBits(1);
			size += "" + bit;
		}
		Integer treeSize = Integer.parseInt(size, 2);
		String treeToBitString = "";
		for (int i = 0; i < treeSize; i++) {
			int bit = bInput.readBits(1);
			treeToBitString += "" + bit;
		}
		rebuildTree(treeToBitString);
	}
	
	//Method that rebuilds a tree from a given string
	private void rebuildTree(String treeBits) throws IOException {
		if(treeBits.length() <= 0 || !isBitString(treeBits))
			throw new IOException("Error: Invalid/Empty Bit String.");
		LinkedList<Integer> chars = new LinkedList<Integer>();
		while(treeBits.length() >= 10){
			char nextBit = treeBits.charAt(0);
			treeBits = treeBits.substring(1);
			if(nextBit == '1'){
				String leafBits = treeBits.substring(0, 9);
				treeBits = treeBits.substring(9);
				int ch = Integer.parseInt(leafBits, 2);
				chars.add(ch);
			}
			else
				chars.add(-1);
		}
		tree = tree.rebuild(chars);
	}
	
	//Method that writes data to the output
	private void writeData(TreeNode node) throws IOException{
		boolean done = false;
		while(!done) {
			int dir = bInput.readBits(1);
			if(dir == 0)
				node = node.getLeft();
			else if(dir == 1)
				node = node.getRight();
			else if(dir == -1){
				bInput.close();
				bOutput.close();
				throw new IOException("Error: No PSEUDO_EOF");
			}
			if(tree.isLeaf(node)){
				if(node.getValue() != PSEUDO_EOF){
					bOutput.writeBits(BITS_PER_WORD, node.getValue());
					output += BITS_PER_WORD;
					node = tree.getTree();
				}
				else
					done = true;
			}
		}
	}

	//Method that checks to see if a given string is all bits
	private boolean isBitString(String treeBits) {
		for(char ch: treeBits.toCharArray()){
			if(ch != '0' && ch != '1')
				return false;
		}
		return true;
	}

	private void showMessage(String string) {
		if(GUI != null)
			GUI.update(string);
		
	}
}
